package com.example.commons.constants;

public interface ImageEncodeConstants {
	int height = 100;
    int width = 100;
    int channels = 1;
    String modelFilePath = "E:/java/image-search-demo/imageEncodeModel.json";
}
