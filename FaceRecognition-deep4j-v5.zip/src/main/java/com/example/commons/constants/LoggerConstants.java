package com.example.commons.constants;

public interface LoggerConstants {
	String TRACE_ID = "traceId";
}
