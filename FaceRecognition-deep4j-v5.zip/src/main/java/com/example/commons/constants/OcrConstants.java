package com.example.commons.constants;

public interface OcrConstants {
	int height = 60;
	int width = 160;
	int channels = 1;
	String textChars = "_234578acdefgmnpwxy";
	String modelFilePath = "model/captcha";
}
