package com.example.service;

public class ProductService implements IProductService{

}
