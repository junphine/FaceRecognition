package com.github.wihoho.constant;

public enum FeatureType {
    PCA,
    LDA,
    LPP;
}