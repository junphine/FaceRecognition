package me.math.optim;



public class LinerOptimTest {

	public static void main(String[] args){
		
		LinearOptimController loc = new LinearOptimController();
		loc.testMath842Cycle();
		
		loc.testLargeModel();
		
	}
}
