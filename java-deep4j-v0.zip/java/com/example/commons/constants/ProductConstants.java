package com.example.commons.constants;

public interface ProductConstants {
	String productImageDirPath = "E:/data/web/productImage";
	String preProcessedProductImageDirPath = "E:/data/web/preProcessedProductImage";
	String productDataDirPath = "E:/data/web/productData";
	String searchImageDirPath = "E:/data/web/searchImage";
}
