package com.example.service;

public interface IProductService {

}
